﻿
using Taller01_grupo04_ConsoleApp;

Console.WriteLine("Maestria");
var marcaMedidor = new Marca("B-METERS");

var cliente001 = new Cliente(
    "Edison", 
    "Ramirez", 
    "edisao@gmail.com", 
    "0994878787", 
    "Quito"
    );

var medidores = new List<Medidor>
{
    new Medidor(
        "Serie001", 
        "Modelo GMDM", 
        marcaMedidor, 
        "Dirección: Quito - Valle de los Chillos", 
        59.99),
    new Medidor(
        "Serie002", 
        "Modelo GMDM", 
        marcaMedidor, 
        "Dirección: Quito - La Armenia", 
        79.99),
    new Medidor("Serie003", 
        "Modelo GMDM", 
        marcaMedidor, 
        "Dirección: Quito - San Rafael", 
        99.99)
};
cliente001.Medidor = new List<Medidor>(medidores);

Console.Write(cliente001);
Console.Write("...");
