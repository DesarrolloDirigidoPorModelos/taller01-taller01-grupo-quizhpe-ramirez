﻿
namespace Taller01_grupo04_ConsoleApp
{
    public class Cliente
    {
        public Cliente(string nombres, string apellidos, string email, string telefonoContacto, string direccion, List<Medidor> medidor = null)
        {
            Id = Guid.NewGuid().ToString();
            Nombres = nombres;
            Apellidos = apellidos;
            Email = email;
            TelefonoContacto = telefonoContacto;
            Direccion = direccion;
            Medidor = medidor;
        }

        public string Id { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public string Email { get; set; }
        public string TelefonoContacto { get; set; }
        public string Direccion { get; set; }
        public List<Medidor> Medidor { get; set; }

    }
}
