﻿
namespace Taller01_grupo04_ConsoleApp
{
    public class Marca
    {
        public Marca(string nombre)
        {
            Id = Guid.NewGuid().ToString();
            Nombre = nombre;
        }

        public string Id { get; }
        public string Nombre { get; set; }
    }
}
