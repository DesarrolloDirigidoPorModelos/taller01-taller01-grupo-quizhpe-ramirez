﻿
namespace Taller01_grupo04_ConsoleApp
{
    public class Medidor
    {
        public Medidor(string serie, string modelo, Marca marca, string direccion, double costo)
        {
            Id = Guid.NewGuid().ToString();
            Serie = serie;
            Modelo = modelo;
            Marca = marca;
            DireccionInstalacion = direccion;
            Costo = costo;
        }

        public string Id { get; set; }
        public string Serie { get; set; }
        public string Modelo { get; set; }
        public Marca Marca { get; set; }
        public string DireccionInstalacion { get; set; }
        public double Costo { get; set; }
    }
}
